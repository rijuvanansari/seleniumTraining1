import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UserLoginPage{
	WebDriver driver;
	@FindBy(how=How.ID, using="username")
	WebElement username;

	@FindBy(how=How.ID, using="password")
	WebElement password;
	
	@FindBy(how=How.ID, using="loginbtn")
	WebElement submit;

    	
	public UserLoginPage(WebDriver driver){
		this.driver = driver;
		driver.get("http://elearning.infogain.com:8383/moodle/login/index.php");
	}
	
	public UserDashboardPage login(){
		username.sendKeys("rijuvan123");
		password.sendKeys("Test@123!");
		submit.click();
		return PageFactory.initElements(driver, UserDashboardPage.class);
	}
}
