package com.soft.nopageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginTestWithoutPageObject {
	public static void main(String... args) {
		String driverLocation = "D:\\Selenium\\ael3\\chrome\\chromedriver.exe";
		// Optional, if not specified, WebDriver will search your path for
		// chromedriver.
		System.setProperty("webdriver.chrome.driver", driverLocation);

		WebDriver driver = new ChromeDriver();

		// Login to Admin portal
		driver.get("http://elearning.infogain.com:8383/moodle/login/index.php");
		WebElement email = driver.findElement(By.id("username"));
		WebElement pwd = driver.findElement(By.id("password"));
		email.sendKeys("rijuvan123");
		pwd.sendKeys("Test@123!");
		WebElement submit = driver.findElement(By.id("loginbtn"));
		submit.click();

	}
}
