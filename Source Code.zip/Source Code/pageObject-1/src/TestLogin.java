import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


public class TestLogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\ael3\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		UserLoginPage loginPage = PageFactory.initElements(driver,UserLoginPage.class);
		
		UserDashboardPage db=loginPage.login();
		db.playCourse();
		
		

	}

}
