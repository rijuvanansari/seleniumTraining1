package three;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class LoginToYahoo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String driverLocation="D:/selenium/selenium-2.44.0/chromedriver_win32/chromedriver.exe";
		  // Optional, if not specified, WebDriver will search your path for chromedriver.
		  System.setProperty("webdriver.chrome.driver", driverLocation);

		  WebDriver driver = new ChromeDriver();
		  driver.get("https://login.yahoo.com/config/mail?.intl=in&.done=https%3A%2F%2Fin-mg61.mail.yahoo.com%3A443%2Fneo%2Flaunch%3F.rand%3D4locvv6rl4mkq");
		  WebElement userName = driver.findElement(By.name("username"));
		  WebElement passwd=driver.findElement(By.name("passwd"));
		  WebElement signIn=driver.findElement(By.id("login-signin"));
		  WebElement keepSign=driver.findElement(By.id("persistent"));
		 
		  userName.sendKeys("rijuvanansari");
		 passwd.sendKeys("");
		  //userName.sendKeys("Abc@123");
		  
			  			  
			  Actions builder1 = new Actions(driver);
			builder1.doubleClick( keepSign).perform();
		  Actions builder = new Actions(driver);
			builder.doubleClick(signIn).perform();
			driver.manage().timeouts().pageLoadTimeout(200000, TimeUnit.SECONDS);
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 WebElement compose =driver.findElement(By.id("yui_3_16_0_1_1430070094496_1589"));
			Actions builder2 = new Actions(driver);
			builder2.doubleClick(compose).perform(); 
	}

}
