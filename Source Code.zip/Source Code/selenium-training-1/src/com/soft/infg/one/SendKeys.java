package com.soft.infg.one;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SendKeys{
public static void main(String[] args){
	System.setProperty("webdriver.chrome.driver", DriverLocation.CHROME);

	  WebDriver driver = new ChromeDriver();
driver.get("http://www.google.com");
WebElement searchBox = driver.findElement(By.name("q"));
searchBox.sendKeys(Keys.chord(Keys.SHIFT,"Infogain India"));
//searchBox.clear();
searchBox.submit();

}
}