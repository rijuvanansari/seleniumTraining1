package com.soft.infg.one;

public class DriverLocation {

	
public static final String CHROME="D:\\Selenium\\ael3\\chrome\\chromedriver.exe";
	
public  static  final String FIREFOX="D:\\Selenium\\ael3\\geckodriver\\gcodriver\\geckodriver.exe";
	
}
