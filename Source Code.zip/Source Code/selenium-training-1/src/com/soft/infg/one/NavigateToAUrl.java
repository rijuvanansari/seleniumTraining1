package com.soft.infg.one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;
public class NavigateToAUrl {
public static void main(String[] args){
	
System.setProperty("webdriver.gecko.driver",DriverLocation.CHROME);
WebDriver driver = new FirefoxDriver();
System.out.println("Navigiating to google");
driver.get("http://www.google.co.in");
WebElement searchBox = driver.findElement(By.name("q"));
WebElement searchBox1 = driver.findElement(By.name("btnK"));
searchBox.sendKeys("Infogain India");
searchBox.submit();

//System.exit(0);
}
}