package two;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import com.soft.infg.one.DriverLocation;

public class ClickAndHold2 {
	public static void main(String... args) {
		System.setProperty("webdriver.chrome.driver", DriverLocation.CHROME);

		WebDriver driver = new ChromeDriver();
		driver.get("D:\\selenium_Training\\Selenium v2\\Sample-HTML\\Sortable.html");
	
		WebElement three = driver.findElement(By.name("three"));

		Actions builder = new Actions(driver);
		// Move tile3 to the position of tile2
		builder.clickAndHold(three).moveByOffset(120, 0).perform();
	}
}
