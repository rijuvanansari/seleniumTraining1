package two;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import com.soft.infg.one.DriverLocation;

public class DragAndDrop {
	public static void main(String... args) {
		System.setProperty("webdriver.chrome.driver", DriverLocation.CHROME);
		ChromeDriver driver=new ChromeDriver();
		driver.get("D:\\selenium_Training\\Selenium v2\\Sample-HTML\\DragAndDrop.html");
		WebElement src = driver.findElement(By.id("draggable"));
		WebElement trgt = driver.findElement(By.id("droppable"));

		Actions builder = new Actions(driver);
		builder.dragAndDrop(src, trgt).perform();
	}
}
