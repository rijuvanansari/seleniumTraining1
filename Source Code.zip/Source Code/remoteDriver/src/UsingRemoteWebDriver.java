

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class UsingRemoteWebDriver {
	public static void main(String... args){
		DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setBrowserName("firefox");
		capabilities.setBrowserName("chrome");
		RemoteWebDriver remoteWD = null;
		try {
			remoteWD = 
					new RemoteWebDriver(new URL("http://127.0.0.1:4444/wd/hub"),capabilities);
					//new RemoteWebDriver(new URL("http://172.18.100.63:4444/wd/hub"),capabilities);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		remoteWD.get("http://www.google.com");
		WebElement element = remoteWD.findElement(By.name("q"));
		element.sendKeys("Infogain India");
	}
}
